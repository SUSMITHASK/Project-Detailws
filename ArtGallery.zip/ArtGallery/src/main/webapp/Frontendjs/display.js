/**
 * 
 */
function appear(){
	var x=document.getElementById("mydiv1");
	if(x.style.display=='none'){
		x.style.display='block';
	}
	else{
		x.style.display='none';
	}
}

function navigate(){
	window.location.href="http://localhost:8085/ArtGallery/PurchaseServlet";
}