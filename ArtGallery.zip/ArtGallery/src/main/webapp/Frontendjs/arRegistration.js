/**
 * 
 */
/**
 * 
 */
function register2(){
	
	 var y=document.forms["form2"]["arname"].value;
	 var a=document.forms["form2"]["araddress"].value;
	 var b=document.forms["form2"]["arphoneno"].value;
	 var c=document.forms["form2"]["arpasswd"].value;
	 var regex=/^[a-zA-Z]+$/;
	 var regex1=/^[0-9]+$/;
	 var regex2=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/;
	if(document.getElementById("arname").value==""){
		alert("Enter your name");
		return false;
	}
	else if(document.getElementById("araddress").value==""){
		alert("Enter your address");
		return false;
	}
	else if(document.getElementById("arphoneno").value==0){
		alert("Enter your phoneno");
		return false;
	}
	else if(!y.match(regex)){
		alert("Enter name with characters only!");
		return false;
	}
	else if(!b.match(regex1)){
		alert("Enter numbers only!");
		return false;
	}
	else if(document.getElementById("arphoneno").value.length!=10){
		alert("Please enter your mobile number with 10 digits");
		return false;
	}
	else if(document.getElementById("arpasswd").value==""){
		alert("Enter new password");
		return false;
	}
	else if(!c.match(regex2)){
		alert("Enter a password between 6 to 20 characters which contain at least one numeric digit, one uppercase, and one lowercase letter");
		return false;
	}
	else if(document.getElementById("arpasswd1").value==""){
		alert("Re-enter the password!");
		return false;
	}
	else if(c!=document.getElementById("arpasswd1").value){
		alert("Enter the same password");
		return false;
	}
	else{
		return true;
	}
	
}

function login(){
	if(document.getElementById("artname").value==""){
		alert("Enter user name");
		return false;
	}
	else if(document.getElementById("artpasswd").value==""){
		alert("Enter valid password");
		return false;
	}
	else{
		return true;
	}
}

