/**
 * 
 */
function register(){
	
	 var y=document.forms["form"]["name"].value;
	 var a=document.forms["form"]["address"].value;
	 var b=document.forms["form"]["phoneno"].value;
	 var c=document.forms["form"]["passwd"].value;
	 var regex=/^[a-zA-Z]+$/;
	 var regex1=/^[0-9]+$/;
	 var regex2=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/;
	if(document.getElementById("name").value==""){
		alert("Enter your name");
		return false;
	}
	else if(document.getElementById("address").value==""){
		alert("Enter your address");
		return false;
	}
	else if(document.getElementById("phoneno").value==0){
		alert("Enter your phoneno");
		return false;
	}
	else if(!y.match(regex)){
		alert("Enter name with characters only!");
		return false;
	}
	else if(!b.match(regex1)){
		alert("Enter numbers only!");
		return false;
	}
	else if(document.getElementById("phoneno").value.length!=10){
		alert("Please enter your mobile number with 10 digits");
		return false;
	}
	else if(document.getElementById("passwd").value==""){
		alert("Enter new password");
		return false;
	}
	else if(!c.match(regex2)){
		alert("Enter a password between 6 to 20 characters which contain at least one numeric digit, one uppercase, and one lowercase letter");
		return false;
	}
	else if(document.getElementById("passwd1").value==""){
		alert("Re-enter the password!");
		return false;
	}
	else if(c!=document.getElementById("passwd1").value){
		alert("Enter the same password");
		return false;
	}
	else{
		return true;
	}
	
	
	}
	/*else{
		navigate();
	}
}

function navigate(){
	window.location.assign("../Frontend/successpage.html");
}*/