package com.inautix.ArtGallery;

import java.util.*;
import java.text.SimpleDateFormat;



public class ArtRentPaymentApp{
	
	

	
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		ArtRentPaymentDao arpd=new ArtRentPaymentDao();
		System.out.println("Enter the choice");
		System.out.println("1.insert 2.update 3.select 4.select by artistid");
		int choice=sc.nextInt();
		switch(choice){
		case 1:
			
			System.out.println("Enter the artist id");
			int artistid=sc.nextInt();
			SimpleDateFormat df=new SimpleDateFormat("dd/MM/yyyy");
			Date d=new Date();
			String date=df.format(d);
			System.out.println("Enter the payment amount");
			float rentamt=sc.nextFloat();
			arpd.insert(artistid,date,rentamt);
			break;
			
		case 2:
			System.out.println("Enter the payment id");
			int payid=sc.nextInt();
			System.out.println("Enter the rent amount to be altered");
			double amt=sc.nextDouble();
			arpd.update(payid,amt);
			break;
			
		case 3:
			System.out.println("Enter the payment id");
			int pid=sc.nextInt();
			List<ArtRentPaymentBean> l=arpd.getDetails(pid);
			Iterator<ArtRentPaymentBean> it=l.iterator();
			while(it.hasNext()){
				ArtRentPaymentBean arpb=it.next();
				System.out.println(arpb.getPaymentId()+"--"+arpb.getArtistId()+"--"+arpb.getDate()+"--"+arpb.getRentAmount());
			}
			break;
		case 4:
			System.out.println("Enter the artist id to view the rent payment details");
			int aid=sc.nextInt();
			List<ArtRentPaymentBean> a=arpd.selectbyartist(aid);
			Iterator<ArtRentPaymentBean> i=a.iterator();
			while(i.hasNext()){
				ArtRentPaymentBean ap=i.next();
				System.out.println(ap.getPaymentId()+"--"+ap.getArtistId()+"--"+ap.getDate()+"--"+ap.getRentAmount());
			}
			break;
		default:
			System.out.println("Enter the choice between 1 and 3");
		}
		sc.close();
	}
}