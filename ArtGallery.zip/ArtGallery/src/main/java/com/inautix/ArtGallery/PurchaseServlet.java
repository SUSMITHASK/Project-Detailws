package com.inautix.ArtGallery;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PurchaseServlet
 */
public class PurchaseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PurchaseServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<head>");
		out.println("<style>body{background:url(http://localhost:8085/ArtGallery/Frontend/backgrnd5.jpg);background-size:cover;}");
		out.println(".alignright{float:right;} img {position: relative;float: left;width:  300px;height: 150px;background-position: 50% 50%;background-repeat:   no-repeat;background-size:     cover;}");
		out.println("</style>");
		out.println("<div class='alignright'><a href='http://localhost:8085/ArtGallery/LogoutServlet'><font size='5'>Log out</font></a></div>");
		out.println("</head>");
		out.println("<body>");
		String imgid=request.getParameter("imgno");
		int artid=Integer.valueOf(imgid);
		List<ArtGalleryBean> l=new ArtGalleryDao().getArt(artid);
		float price=0.0f;
		String imgpath=null;
		int artistid=0;
		Iterator<ArtGalleryBean> it=l.iterator();
		while(it.hasNext()){
			ArtGalleryBean a=it.next();
			price=a.getPrice();
			imgpath=a.getImg();
			artistid=a.getArtistId();
		}
		String artistname=new ArtArtistDao().getArtistName(artistid);
		out.println("<img src='"+imgpath+"' />");
		out.println("<br><br><br><br>");
		out.println("<div class='alignright>'");
		out.println("<br><br><br><br><br><br><br><br>");
		out.println("<font size='6'><b>Artist:&nbsp</b>"+artistname+"</font>");
		out.println("<br><br>");
		out.println("<font size='6'><b>Price:&nbsp</b>Rs. "+price+"</font>");
		out.println("<br><br>");
		out.println("</div>");
		out.println("<form action='http://localhost:8085/ArtGallery/CustomerPayment'>");
		out.println("<input type='hidden' name='artid' value='"+artid+"'/>");
		//out.println("<input type='hidden' name='price' value='"+price+"'/>");
		
		out.println("<input type='submit' value='Buy' />");
		out.println("<form>");
		out.println("</body>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
