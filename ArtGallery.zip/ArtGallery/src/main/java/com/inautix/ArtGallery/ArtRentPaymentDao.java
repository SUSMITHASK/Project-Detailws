package com.inautix.ArtGallery;

import java.sql.*;
import java.util.*;



public class ArtRentPaymentDao{
	
	
	public void insert(int artistid,String date,float rentamt){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		String query="insert into T_XBBNHHA_PAYMENT(artistid,paymentdate,rentamt) values(?,?,?)";
		try{
			stmt=con.prepareStatement(query);
			
			stmt.setInt(1,artistid);
			stmt.setString(2,date);
			stmt.setFloat(3, rentamt);
			stmt.executeUpdate();
			System.out.println("Records inserted");
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
	}
	
	public List<ArtRentPaymentBean> getDetails(int paymentid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String query="Select * from T_XBBNHHA_PAYMENT where paymentid=?";
		List<ArtRentPaymentBean> l=null;
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(1,paymentid);
			
			l=new ArrayList<ArtRentPaymentBean>();
			rs=stmt.executeQuery();
			while(rs.next()){
				ArtRentPaymentBean arpb=new ArtRentPaymentBean();
				arpb.setPaymentId(rs.getInt("PAYMENTID"));
				arpb.setArtistId(rs.getInt("ARTISTID"));
				arpb.setDate(rs.getString("PAYMENTDATE"));
				arpb.setRentAmount(rs.getDouble("RENTAMT"));
				l.add(arpb);
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
				if(rs!=null){
					rs.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		return l;
	}
	
	public List<ArtRentPaymentBean> selectbyartist(int artistid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String query="Select * from T_XBBNHHA_PAYMENT where artistid=?";
		List<ArtRentPaymentBean> l=null;
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(1,artistid);
			
			l=new ArrayList<ArtRentPaymentBean>();
			rs=stmt.executeQuery();
			while(rs.next()){
				ArtRentPaymentBean arpb=new ArtRentPaymentBean();
				arpb.setPaymentId(rs.getInt("PAYMENTID"));
				arpb.setArtistId(rs.getInt("ARTISTID"));
				arpb.setDate(rs.getString("PAYMENTDATE"));
				arpb.setRentAmount(rs.getDouble("RENTAMT"));
				l.add(arpb);
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
				if(rs!=null){
					rs.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		return l;
	}
	
	public void update(int paymentid,double rentamt){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		String query="Update T_XBBNHHA_PAYMENT set rentamt=? where paymentid=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setDouble(1,rentamt);
			stmt.setInt(2,paymentid);
			stmt.executeUpdate();
			System.out.println("Details updated");
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
	}
}