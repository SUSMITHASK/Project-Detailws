package com.inautix.ArtGallery;

//import java.util.*;

public class ArtGalleryBean{
	private int artid;
	private int artistid;
	private String arttype;
	private float price;
	private String img;
	
	public int getArtId(){
		return artid;
	}
	
	public void setArtId(int artid){
		this.artid=artid;
	}
	
	public int getArtistId(){
		return artistid;
	}
	
	public void setArtistId(int artistid){
		this.artistid=artistid;
	}
	
	public String getArtType(){
		return arttype;
	}
	
	public void setArtType(String arttype){
		this.arttype=arttype;
	}
	
	
	public float getPrice(){
		return price;
	}
	
	public void setPrice(float price){
		this.price=price;
	}
	
	public String getImg(){
		return img;
	}
	
	public void setImg(String img){
		this.img=img;
	}
}