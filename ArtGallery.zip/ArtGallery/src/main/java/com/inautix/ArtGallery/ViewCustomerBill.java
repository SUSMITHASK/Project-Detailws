package com.inautix.ArtGallery;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ViewCustomerBill
 */
public class ViewCustomerBill extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewCustomerBill() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String custname="";
		float sum=0.0f;
		Cookie c[]=request.getCookies();
		if(c!=null){
			for(int i=0;i<c.length;i++){
				if(c[i].getName().equals("name")){
					custname=c[i].getValue();
				}
			}
		}
		out.println("<head>");
		out.println("<style>");
		out.println("body{background:url(http://localhost:8085/ArtGallery/Frontend/backgrnd5.jpg);background-size:cover;}");
		out.println(".alignright{float:right;} ");
		out.println("</style>");
		out.println("</head>");
		out.println("<center>");
		out.println("<br><br>");
		out.println("<center><font size='6'><b>Your Previous Transactions</b></font></center>");
		out.println("<br><br><br><br>");
		out.println("<br><br><div class='alignright'><a href='http://localhost:8085/ArtGallery/LogoutServlet'><font size='5'>Log out</font></a></div>");
		out.println("<table border='1'><tr><font size='5'><th>Art Id</th><th>Art</th><th>Price</th></font></tr>");
		int custid=new ArtCustomerDao().getCustId(custname);
		List<ArtTransactionBean> l=new ArtTransactionDao().getBillDetails(custid);
		Iterator<ArtTransactionBean> it=l.iterator();
		while(it.hasNext()){
			ArtTransactionBean art=it.next();
			ArtTransactionDao ag=new ArtTransactionDao();
			sum+=art.getPrice();
			out.println("<tr><font size='4'><td>"+art.getArtId()+"</td><td>"+ag.getArtType(art.getArtId())+"</td><td>"+art.getPrice()+"</td></font></tr>");
		}
		out.println("</table>");
		out.println("<br><br>");
		out.println("<font size='5'>Your bill total along with your previous purchases is Rs.&nbsp"+sum+"</font>");
		out.println("</center>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
