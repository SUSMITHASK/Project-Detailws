package com.inautix.ArtGallery;

import java.sql.*; 
import java.util.*;



public class ArtArtistDao{
	


	
	public void insert(String artistname, String artistaddr, String artistcontactno,String apasswd){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		String query="insert into T_XBBNHHA_ARTIST(artistname,artistaddr,contactinfo) values(?,?,?)";
		String query1="insert into T_XBBNHHA_ARTIST_LOGIN values(?,?)";
		try{
			stmt=con.prepareStatement(query);
			stmt.setString(1,artistname);
			stmt.setString(2,artistaddr);
			stmt.setString(3,artistcontactno);
			stmt.executeUpdate();
			
			stmt.close();
			stmt=con.prepareStatement(query1);
			stmt.setString(1,artistname);
			stmt.setString(2,apasswd);
			stmt.executeUpdate();
			System.out.println("Data inserted successfully");
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
	}
	public void updateName(int artistid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the artist name:");
		String artistname=sc.next();
		String query="update T_XBBNHHA_ARTIST set artistname=? where artistid=?";
		sc.close();
		try{
			stmt=con.prepareStatement(query);
			stmt.setString(1,artistname);
			stmt.setInt(2,artistid);
			stmt.executeUpdate();
			System.out.println("Detail updated");
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
	}
	
	public void updateAddr(int artistid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the artist address:");
		sc.nextLine();
		String artistaddr=sc.nextLine();
		String query="update T_XBBNHHA_ARTIST set artistaddr=? where artistid=?";
		sc.close();
		try{
			stmt=con.prepareStatement(query);
			stmt.setString(1,artistaddr);
			stmt.setInt(2,artistid);
			stmt.executeUpdate();
			System.out.println("Detail updated");
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
	}

	public void updateContact(int artistid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the artist contact no:");
		String artistcontactinfo=sc.next();
		String query="update T_XBBNHHA_ARTIST set artistcontactinfo=? where artistid=?";
		sc.close();
		try{
			stmt=con.prepareStatement(query);
			stmt.setString(1,artistcontactinfo);
			stmt.setInt(2,artistid);
			stmt.executeUpdate();
			System.out.println("Detail updated");
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
	}
	
	public void delete(int artistid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		String query="delete from T_XBBNHHA_ARTIST where artistid=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(1,artistid);
			stmt.executeUpdate();
			System.out.println("Row Deleted");
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
	}
	
	public List<ArtArtistBean> select(int artistid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		List<ArtArtistBean> al=null;
		String query="select * from T_XBBNHHA_ARTIST where artistid=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(1, artistid);
			rs=stmt.executeQuery();
			al=new ArrayList<ArtArtistBean>();
			while(rs.next()){
				ArtArtistBean aab=new ArtArtistBean();
				aab.setArtistId(rs.getInt("ARTISTID"));
				aab.setArtistName(rs.getString("ARTISTNAME"));
				aab.setArtistAddr(rs.getString("ARTISTADDR"));
				aab.setArtistContact(rs.getString("CONTACTINFO"));
				al.add(aab);
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		
		return al;
		
	}
	public int loginCheck(String artistname, String artistpasswd) {
		// TODO Auto-generated method stub
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		int flag=0;
		String query="select * from T_XBBNHHA_ARTIST_LOGIN where aname=? and pwd=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setString(1,artistname);
			stmt.setString(2,artistpasswd);
			rs=stmt.executeQuery();
			while(rs.next()){
				flag=1;
				break;
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		return flag;
	}
	public int getArtistId(String artistname){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		int artistid=0;
		String query="select artistid from T_XBBNHHA_ARTIST where artistname=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setString(1,artistname);
			rs=stmt.executeQuery();
			while(rs.next()){
				artistid=rs.getInt("ARTISTID");
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		return artistid;
	}
	public String getArtistName(int artistId) {
		// TODO Auto-generated method stub
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String artistname=null;
		String query="select artistname from T_XBBNHHA_ARTIST where artistid=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(1,artistId);
			rs=stmt.executeQuery();
			while(rs.next()){
				artistname=rs.getString("ARTISTNAME");
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		return artistname;
	}
	
}