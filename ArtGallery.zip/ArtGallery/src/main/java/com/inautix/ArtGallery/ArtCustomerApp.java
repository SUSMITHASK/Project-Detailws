package com.inautix.ArtGallery;

import java.util.*;


public class ArtCustomerApp{
	


	
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the choice");
		System.out.println("1.insert 2.select 3.update 4.delete");
		int choice=sc.nextInt();
		if(choice==1){
			//System.out.println("Enter the customer id");
			//int custid=sc.nextInt();
			System.out.println("Enter the customer name");
			String custname=sc.next();
			System.out.println("Enter the customer address");
			sc.nextLine();
			String custaddr=sc.nextLine();
			System.out.println("Enter the customer contact no");
			String custphoneno=sc.nextLine();
			System.out.println("Enter the password");
			String passwd=sc.nextLine();
			ArtCustomerDao acd=new ArtCustomerDao();
			acd.insertDetails(custname,custaddr,custphoneno,passwd);
		}
		else if(choice==2){
			System.out.println("Enter the customer id");
			int custid=sc.nextInt();
			ArtCustomerDao acd=new ArtCustomerDao();
			List<ArtCustomerBean> acb=acd.display(custid);
			Iterator<ArtCustomerBean> it=acb.iterator();
			while(it.hasNext()){
				ArtCustomerBean ac=it.next();
				System.out.println(ac.getCustId()+"/"+ac.getCustName()+"/"+ac.getCustAddr()+"/"+ac.getCustPhoneNo());
			}
		}
		else if(choice==3){
			System.out.println("Enter the customer id");
			int custid=sc.nextInt();
			ArtCustomerDao acd=new ArtCustomerDao();
			System.out.println("Which attribute do u want to update");
			System.out.println("1.customer name  2.customer address  3.customer contact no");
			int ch=sc.nextInt();
			switch(ch){
			case 1:acd.updateName(custid);
			break;
			
			case 2:acd.updateAddress(custid);
			break;
			
			case 3:acd.updatePhoneNo(custid);
			break;
			
			default:System.out.println("Enter the choice between 1 and 3");
			}
		}
		else if(choice==4){
			System.out.println("Enter the customer id");
			int custid=sc.nextInt();
			ArtCustomerDao acd=new ArtCustomerDao();
			acd.delete(custid);
		sc.close();
	}
		else{
			System.out.println("Enter choice between 1 and 4");
		}
	
	}
}