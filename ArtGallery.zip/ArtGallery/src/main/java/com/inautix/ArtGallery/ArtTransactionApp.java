package com.inautix.ArtGallery;

import java.util.*;



public class ArtTransactionApp{
	
	

	
	public static void main(String args[]){

		Scanner sc=new Scanner(System.in);
		ArtTransactionDao atd=new ArtTransactionDao();
		System.out.println("Enter the choice");
		System.out.println("1.insert 2.select 3.print bill");
		int choice=sc.nextInt();
		int transactionid;
		int artid;
		int custid;
		switch(choice){
		case 1:
			System.out.println("Enter the art id");
			artid=sc.nextInt();
			System.out.println("Enter the customer id");
			custid=sc.nextInt();
			atd.insert(artid,custid);
			break;
			
		case 2:
			System.out.println("Enter the transaction id");
			transactionid=sc.nextInt();
			List<ArtTransactionBean> l=atd.selectDetails(transactionid);
			Iterator<ArtTransactionBean> it=l.iterator();
			while(it.hasNext()){
				ArtTransactionBean a=it.next();
				System.out.println(a.getTransactionId()+"/"+a.getArtId()+"/"+a.getCustomerId()+"/"+a.getPrice());
			}
			break;
			
		case 3:
			System.out.println("Enter the customer id");
			int cid=sc.nextInt();
			double sum=atd.billtotal(cid);
			String custname=atd.returnName(cid);
			System.out.println("The bill total for "+custname+" is "+sum);
			System.out.println();
			System.out.println("Complete bill details:");
			System.out.println();
			List<ArtTransactionBean> la=atd.getBillDetails(cid);
			Iterator<ArtTransactionBean> itr=la.iterator();
			System.out.println("Artid--ArtType--Price");
			while(itr.hasNext()){
				ArtTransactionBean atb=itr.next();
				int aid=atb.getArtId();
				String arttype=atd.getArtDetail(aid);
				System.out.println(aid+"--"+arttype+"--"+atb.getPrice());
			}
			break;
			
		default:System.out.println("Enter choice between 1 and 3");
		}
		sc.close();
	}
}