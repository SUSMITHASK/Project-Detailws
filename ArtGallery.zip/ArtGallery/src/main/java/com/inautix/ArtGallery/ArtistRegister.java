package com.inautix.ArtGallery;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ArtistRegister
 */
public class ArtistRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ArtistRegister() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String aname=request.getParameter("arname");
		String araddr=request.getParameter("araddress");
		String aphoneno=request.getParameter("arphoneno");
		String apasswd=request.getParameter("arpasswd");
		
		HttpSession session=request.getSession();
		session.setAttribute("artistname",aname);
		
		ArtArtistDao ad=new ArtArtistDao();
		ad.insert(aname,araddr,aphoneno,apasswd);
		out.println("<head><style>");
		out.println("body{background:url(http://localhost:8085/ArtGallery/Frontend/background7.jpg)}");
		out.println("</style></head>");
		out.println("<br><br><br><br>");
		out.println("<center><font size='6' color='white'><b>Registration Successful!!</b></font>");
		out.println("<br><br>");
		out.println("<form action='http://localhost:8085/ArtGallery/artistsite'>");
		out.println("<input type='hidden' name='artiname' value='"+aname+"'>");
		out.println("<input type='submit' value='continue'>");
		out.println("</center>");
		out.print("</form>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
