package com.inautix.ArtGallery;

public class ArtTransactionBean{
	private int transactionid;
	private int artid;
	private int custid;
	private double price;
	
	public int getTransactionId(){
		return transactionid;
	}
	
	public void setTransactionId(int transactionid){
		this.transactionid=transactionid;
	}
	
	public int getArtId(){
		return artid;
	}
	
	public void setArtId(int artid){
		this.artid=artid;
	}
	
	public int getCustomerId(){
		return custid;
	}
	
	public void setCustomerId(int custid){
		this.custid=custid;
	}
	
	public double getPrice(){
		return price;
	}
	
	public void setPrice(double price){
		this.price=price;
	}
}