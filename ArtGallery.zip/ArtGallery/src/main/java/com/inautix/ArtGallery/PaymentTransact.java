package com.inautix.ArtGallery;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet implementation class PaymentTransact
 */
public class PaymentTransact extends HttpServlet {
	
	

	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PaymentTransact() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession(true);
		String artistname=(String)session.getAttribute("artistname");
		ArtArtistDao aa=new ArtArtistDao();
		System.out.println(artistname);
		int artistid=aa.getArtistId(artistname);
		System.out.println(artistid);
		String paymentdate=request.getParameter("date");
		String rentStringAmt=request.getParameter("rentamt");
		Double rentDoubleAmt=Double.parseDouble(rentStringAmt);
		float rentamt=rentDoubleAmt.floatValue();
		ArtRentPaymentDao ar=new ArtRentPaymentDao();
		ar.insert(artistid, paymentdate, rentamt);
		System.out.println(paymentdate+""+rentamt);
		RequestDispatcher rd=request.getRequestDispatcher("/Frontend/PaymentDetails.jsp");
		rd.include(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
