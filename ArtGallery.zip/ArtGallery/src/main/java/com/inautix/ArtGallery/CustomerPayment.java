package com.inautix.ArtGallery;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CustomerPayment
 */
public class CustomerPayment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerPayment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String artStringid=request.getParameter("artid");
		int artid=Integer.valueOf(artStringid);
		Cookie ck[]=request.getCookies();
		String custname=null;
		if(ck!=null){
			for(int i=0;i<ck.length;i++){
				if(ck[i].getName().equals("name")){
					custname=ck[i].getValue();
				}
			}
		}
		int custid=new ArtCustomerDao().getCustId(custname);
		ArtTransactionDao ar=new ArtTransactionDao();
		ar.insert(artid, custid);
		List<ArtTransactionBean> l=ar.getBillDetails(custid);
		Iterator<ArtTransactionBean> it=l.iterator();
		float sum=0.0f;
		out.println("<head>");
		out.println("<style>");
		out.println("body{background:url(http://localhost:8085/ArtGallery/Frontend/backgrnd5.jpg);background-size:cover;}");
		out.println(".alignright{float:right;} table,tr,th,td{border: 1px solid black} th, td {padding: 15px;text-align: left;}a{float:right;right:10px;top:10px}");
		out.println("</style>");
		out.println("<script src='/ArtGallery/Frontendjs/display.js'></script>");
		out.println("</head>");
		out.println("<body>");
		out.println("<br><br>");
		out.println("<a href='http://localhost:8085/ArtGallery/LogoutServlet'><font size='4' color=><b>Log out</b></font></a>");
		out.println("<br><br><br>");
		out.println("<center><font size='6'><b>Your transaction is successful!!</b></font><center>");
		out.println("<br><br>");
		out.println("<input type='button' value='View Bill' onclick='appear()'>");
		out.println("<div id='mydiv1' style='display:none;'>");
		out.println("<br><br>");
		out.println("<font size='6'><b>Customer Name:&nbsp</b>"+custname+"</font");
		out.println("<br><br><br><br>");
		out.println("<table><tr><font size='5'><th>Art Id</th><th>Art</th><th>Price</th></font></tr>");
		while(it.hasNext()){
			ArtTransactionBean a=it.next();
			ArtTransactionDao ag=new ArtTransactionDao();
			sum+=a.getPrice();
			out.println("<tr><font size='4'><td>"+a.getArtId()+"</td><td>"+ag.getArtType(a.getArtId())+"</td><td>"+a.getPrice()+"</td></font></tr>");
		}
		out.println("</table>");
		out.println("<font size='5'>Your bill total along with your previous purchases is Rs.&nbsp"+sum+"</font>");
		out.println("</div>");
		out.println("</body>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
