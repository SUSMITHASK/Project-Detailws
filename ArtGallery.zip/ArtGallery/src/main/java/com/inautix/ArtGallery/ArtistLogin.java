package com.inautix.ArtGallery;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ArtistLogin
 */
public class ArtistLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ArtistLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String artistname=request.getParameter("artname");
		String artistpasswd=request.getParameter("artpasswd");
		ArtArtistDao a=new ArtArtistDao();
		int result=a.loginCheck(artistname,artistpasswd);
		if(result==1){
			HttpSession session=request.getSession();
			session.setAttribute("artistname",artistname);
			out.println("<center><font size='4' color='white'><b>Welcome&nbsp"+artistname+"</b></font></center>");
			RequestDispatcher rd=request.getRequestDispatcher("/Frontend/ArtistHome.html");
			rd.include(request,response);
		}
		else{
			out.print("<br><center><b><font size='4' color='white'>Sorry!!User name or password wrong</font></b></center>");
			RequestDispatcher rd=request.getRequestDispatcher("/Frontend/Artist.html");
			rd.include(request, response);
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
