package com.inautix.ArtGallery;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CustomerViewArt
 */
public class CustomerViewArt extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerViewArt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<head>");
		out.println("<style>body{background:url(http://localhost:8085/ArtGallery/Frontend/backgrnd5.jpg);background-size:cover;}");
		out.println(".alignright{float:right;} .alignleft{float:left;} img {position: relative;float: left;width:  300px;height: 150px;background-position: 50% 50%;background-repeat:   no-repeat;background-size:     cover;}");
		out.println("a:link{text-decoration:none;} a:visited{text-decoration:none;}");
		out.println("</style>");
		out.println("<script>");
		out.println("function setValue(id){document.getElementById('p1').setAttribute('value',id);}");
		out.println("</script>");
		out.println("</head>");
		out.println("<body>");
		out.println("<center><font size='8' color=#4d7498>Gallery</font></center>");
		out.println("<br><br><div class='alignright'><a href='http://localhost:8085/ArtGallery/LogoutServlet'><font size='5'>Log out</font></a></div>");
		out.println("<div class='alignleft'>");
		out.println("<a href='http://localhost:8085/ArtGallery/ViewCustomerBill'><font size='6'>View Previous Bills</font></a>");
		out.println("</div>");
		out.println("<form action='http://localhost:8085/ArtGallery/PurchaseServlet'>");
		out.println("<br><br><br><center>");
		out.println("<table border='1'>");
		ArtGalleryDao ad=new ArtGalleryDao();
		List<ArtGalleryBean> l=ad.selectDetails();
		Iterator<ArtGalleryBean> it=l.iterator();
		while(it.hasNext()){
			ArtGalleryBean ab=it.next();
			ArtArtistDao a=new ArtArtistDao();
			//HttpSession session=request.getSession(true);
			String artistname=a.getArtistName(ab.getArtistId());
			out.println("<tr>");
			out.println("<td><img src='"+ab.getImg()+"'</td>");
			out.println("<td><font size='5'><b>"+artistname+"</b></font></td>");
			out.println("<td><font size='5'><b>"+ab.getPrice()+"</b></font></td>");
			out.println("<td><input type='submit' value='Buy' name='purchase' onclick='setValue(this.id)' id='"+ab.getArtId()+"'></td>");
			
			out.println("</tr>");
		}
		out.println("</table>");
		out.println("</center>");
		out.println("<input type='hidden' id='p1' name='imgno' value='' />");
		out.println("</form>");
		out.println("</body>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
