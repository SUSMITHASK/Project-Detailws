package com.inautix.ArtGallery;

public class ArtRentPaymentBean{
	private int paymentid;
	private int artistid;
	private String date;
	private double rentamt;
	
	public int getPaymentId(){
		return paymentid;
	}
	
	public void setPaymentId(int paymentid){
		this.paymentid=paymentid;
	}
	
	public int getArtistId(){
		return artistid;
	}
	
	public void setArtistId(int artistid){
		this.artistid=artistid;
	}
	
	public String getDate(){
		return date;
	}
	
	public void setDate(String date){
		this.date=date;
	}
	
	public double getRentAmount(){
		return rentamt;
	}
	
	public void setRentAmount(double rentamt){
		this.rentamt=rentamt;
	}
}