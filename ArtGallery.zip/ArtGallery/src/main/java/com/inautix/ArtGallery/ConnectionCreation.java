package com.inautix.ArtGallery;

import java.sql.*;

public class ConnectionCreation {
	static Connection getConn(){
		try{
			Class.forName("org.apache.derby.jdbc.ClientDriver");
		}
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		Connection conn=null;
		try{
			conn=DriverManager.getConnection("jdbc:derby://172.24.19.24:1527/ArtGallery","Susmitha","Susmitha");
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		return conn;
	}
}
