package com.inautix.ArtGallery;

import java.util.*;
import java.sql.*;




public class ArtGalleryDao{
	
	
	
	public List<ArtGalleryBean> getArt(int artid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		List<ArtGalleryBean> galleryDetails=null;
		String query="SELECT * from T_XBBNHHA_ARTWORK where artid= ?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(1,artid);
			
			rs=stmt.executeQuery();
			galleryDetails=new ArrayList<ArtGalleryBean>();
			while(rs.next()){
				ArtGalleryBean artGalleryBean=new ArtGalleryBean();
				artGalleryBean.setArtId(rs.getInt("ARTID"));
				artGalleryBean.setArtistId(rs.getInt("ARTISTID"));
				artGalleryBean.setArtType(rs.getString("ARTTYPE"));
				artGalleryBean.setPrice(rs.getFloat("PRICE"));
				artGalleryBean.setImg(rs.getString("IMG"));
				galleryDetails.add(artGalleryBean);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		return galleryDetails;
	}
	
	public void insertDetails(int artistid,String arttype,float price,String imgpath){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		//ResultSet rs=null;
		String query="insert into T_XBBNHHA_ARTWORK(artistid,arttype,price,img) values(?,?,?,?)";
		try{
			stmt=con.prepareStatement(query);
			
			stmt.setInt(1,artistid);
			stmt.setString(2,arttype);
			
			stmt.setFloat(3,price);
			stmt.setString(4,imgpath);
			stmt.executeUpdate();
			System.out.println("Data inserted successfully!");
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
	}
	
	public void update(int artid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("Which attribute do you want to update?");
		System.out.println("1.Art type  2.Availability 3.Price");
		int choice=sc.nextInt();
		if(choice==1){
			System.out.println("Enter the new value of art type");
			String arttype=sc.next();
			String query="update T_XBBNHHA_ARTWORK set arttype=? where artid=?";
			try{
				stmt=con.prepareStatement(query);
				stmt.setString(1,arttype);
				stmt.setInt(2,artid);
				stmt.executeUpdate();
				//Statement stmt;
				//stmt=con.createStatement();
				//String query="update T_XBBNHHA_ARTWORK set arttype='"+arttype+"' where artid="+artid;
				//stmt.executeUpdate(query);
				System.out.println("Updated details!");
			}
			catch(SQLException e){
				e.printStackTrace();
			}
			finally{
				try{
					if(stmt!=null){
						stmt.close();
					}
					if(con!=null){
						con.close();
					}
				}
				catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		else if(choice==2){
			System.out.println("Enter the new value of availability");
			int availability=sc.nextInt();
			String query="update T_XBBNHHA_ARTWORK set availability=? where artid=?";
			try{
				stmt=con.prepareStatement(query);
				stmt.setInt(1,availability);
				stmt.setInt(2,artid);
				stmt.executeUpdate();
				//PreparedStatement stmt;
				System.out.println("Updated details!");
			}
			catch(SQLException e){
				e.printStackTrace();
			}
			finally{
				try{
					if(stmt!=null){
						stmt.close();
					}
					if(con!=null){
						con.close();
					}
				}
				catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		else if(choice==3){
			System.out.println("Enter the new value of price");
			float price=sc.nextFloat();
			String query="update T_XBBNHHA_ARTWORK set price=? where artid=?";
			try{
				stmt=con.prepareStatement(query);
				stmt.setFloat(1,price);
				stmt.setInt(2,artid);
				stmt.executeUpdate();
				//PreparedStatement stmt;
				System.out.println("Updated details!");
			}
			catch(SQLException e){
				e.printStackTrace();
			}
			finally{
				try{
					if(stmt!=null){
						stmt.close();
					}
					if(con!=null){
						con.close();
					}
				}
				catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
		else{
			System.out.println("Enter choice between 1 and 3");
		}
		sc.close();
		
	}
	
	public void delete(int artid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		String query="Delete from T_XBBNHHA_ARTWORK where artid=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(1,artid);
			stmt.executeUpdate();
			System.out.println("The specified row deleted");
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
	}
	public String getArtistId(int artid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String query="select artistname from T_XBBNHHA_ARTIST where artistid=(select artistid from T_XBBNHHA_ARTWORK where artid=?)";
		String artistname=null;
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(1,artid);
			rs=stmt.executeQuery();
			while(rs.next()){
				artistname=rs.getString("ARTISTNAME");
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
				if(rs!=null){
					rs.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		return artistname;
	}
	
	public double getPrice(int artid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String query="select price from T_XBBNHHA_ARTWORK where artid=?";
		double p=0.0;
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(1,artid);
			rs=stmt.executeQuery();
			while(rs.next()){
				p=rs.getDouble("PRICE");
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
				if(rs!=null){
					rs.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		return p;
	}

	public List<ArtGalleryBean> selectDetails() {
		// TODO Auto-generated method stub
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		List<ArtGalleryBean> l=null;
		String query="select * from T_XBBNHHA_ARTWORK";
		try{
			stmt=con.prepareStatement(query);
			rs=stmt.executeQuery();
			l=new ArrayList<ArtGalleryBean>();
			while(rs.next()){
				ArtGalleryBean ab=new ArtGalleryBean();
				ab.setArtId(rs.getInt("ARTID"));
				ab.setArtistId(rs.getInt("ARTISTID"));
				ab.setArtType(rs.getString("ARTTYPE"));
				ab.setPrice(rs.getFloat("PRICE"));
				ab.setImg(rs.getString("IMG"));
				l.add(ab);
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		return l;
	}
}