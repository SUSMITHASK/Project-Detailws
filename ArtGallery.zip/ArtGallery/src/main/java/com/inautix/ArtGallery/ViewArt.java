package com.inautix.ArtGallery;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ViewArt
 */
public class ViewArt extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewArt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		ArtGalleryDao ad=new ArtGalleryDao();
		List<ArtGalleryBean> l= ad.selectDetails();
		Iterator<ArtGalleryBean> it=l.iterator();
		out.println("<head><title>View Gallery</title><center><font size='16' color=#4d7498>Gallery</font></center><style>body{background:url(http://localhost:8085/ArtGallery/Frontend/backgrnd5.jpg);background-repeat:no-repeat;background-size:cover} img {position: relative;float: left;width:  300px;height: 150px;background-position: 50% 50%;background-repeat:   no-repeat;background-size:     cover;} .alightright{float:right;}</style></head>");
		out.println("<br><br><br>");
		out.println("<body>");
		out.println("<div class='alignright'><a href='http://localhost:8085/ArtGallery/ArtistLogout'><font size='4'><b>Log out</b></font></a></div>");
		out.println("<center>");
		out.println("<table>");
		while(it.hasNext()){
			ArtGalleryBean ab=it.next();
			ArtArtistDao aa=new ArtArtistDao();
			String artistname=aa.getArtistName(ab.getArtistId());
			out.println("<tr>");
			out.println("<td><img src='"+ab.getImg()+"' /></td>");
			out.println("<td>&nbsp&nbsp&nbsp<font size='5'>"+artistname+"</font></td>");
			out.println("<td>&nbsp&nbsp&nbsp<font size='5'>"+ab.getPrice()+"</font></td>");
			//out.println("<td>"+ab.get+"</td>");
			out.println("</tr>");
		}
		out.println("</table>");
		out.println("</center>");
		out.println("</body>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
