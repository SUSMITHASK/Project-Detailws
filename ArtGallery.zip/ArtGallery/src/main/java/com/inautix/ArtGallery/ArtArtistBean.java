package com.inautix.ArtGallery;

public class ArtArtistBean{
	private int artistid;
	private String artistname;
	private String artistaddr;
	private String artistcontactinfo;
	private String apasswd;
	
	public void setAPasswd(String apasswd){
		this.apasswd=apasswd;
	}
	
	public String getAPasswd(){
		return apasswd;
	}
	
	public void setArtistId(int artistid){
		this.artistid=artistid;
	}
	
	public int getArtistId(){
		return artistid;
	}
	
	public void setArtistName(String artistname){
		this.artistname=artistname;
	}
	
	public String getArtistName(){
		return artistname;
	}
	
	public void setArtistAddr(String artistaddr){
		this.artistaddr=artistaddr;
	}
	
	public String getArtistAddr(){
		return artistaddr;
	}
	
	public void setArtistContact(String artistcontactinfo){
		this.artistcontactinfo=artistcontactinfo;
	}
	
	public String getArtistContact(){
		return artistcontactinfo;
	}
	
	
}