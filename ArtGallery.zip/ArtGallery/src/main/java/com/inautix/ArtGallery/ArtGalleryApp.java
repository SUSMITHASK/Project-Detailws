package com.inautix.ArtGallery;

import java.util.*;


public class ArtGalleryApp{
	
	
	
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		int choice;
		System.out.println("Enter the choice");
		System.out.println("1.Insert 2.Select 3.Update 4.Delete");
		choice=sc.nextInt();
		if(choice==1){
			System.out.println("Enter the artistid");
			int artistid=sc.nextInt();
			System.out.println("Enter the art type");
			String arttype=sc.next();

			System.out.println("Enter the price");
			float price=sc.nextFloat();
			System.out.println("Enter the image path");
			String imgpath=sc.next();
			ArtGalleryDao agb=new ArtGalleryDao();
			agb.insertDetails(artistid,arttype,price,imgpath);
		}
		else if(choice==2){
			System.out.println("Enter the artid");
			int artid=sc.nextInt();
			ArtGalleryDao artGalleryDao=new ArtGalleryDao();
			List<ArtGalleryBean> galleryDetails=artGalleryDao.getArt(artid);
			Iterator<ArtGalleryBean> it=galleryDetails.iterator();
			while(it.hasNext()){
				ArtGalleryBean agb=it.next();
				System.out.println(agb.getArtId()+"/"+agb.getArtistId()+"/"+agb.getArtType()+"/"+agb.getPrice());;
			}
		}
		else if(choice==3){
			System.out.println("Enter the artid");
			int artid=sc.nextInt();
			ArtGalleryDao agb=new ArtGalleryDao();
			agb.update(artid);
		}
		else if(choice==4){
			System.out.println("Enter the artid to delete the row");
			int artid=sc.nextInt();
			ArtGalleryDao agb=new ArtGalleryDao();
			agb.delete(artid);
		}
		else{
			System.out.println("Enter the choice between 1 and 4");
		}
		sc.close();
		
	}
}