package com.inautix.ArtGallery;

import java.util.*;
import java.sql.*;



public class ArtTransactionDao{
	


	
	public void insert(int artid,int custid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		String query1="select price from T_XBBNHHA_ARTWORK where artid=?";
		String query2="insert into T_XBBNHHA_TRANSACTION(artid,custid,price) values(?,?,?)";
		Double price=0.0;
		ResultSet rs=null;
		try{
			stmt=con.prepareStatement(query1);
			stmt.setInt(1,artid);
			rs=stmt.executeQuery();
			while(rs.next()){
				price=rs.getDouble("PRICE");
			}
			
			stmt.close();
			
			stmt=con.prepareStatement(query2);
			stmt.setInt(1,artid);
			stmt.setInt(2, custid);
			stmt.setDouble(3, price);
			stmt.executeUpdate();
			System.out.println("Data inserted successfully");
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
				if(rs!=null){
					rs.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
	}
	
	public List<ArtTransactionBean> selectDetails(int transactionid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		List<ArtTransactionBean> l=null;
		String query="select * from T_XBBNHHA_TRANSACTION where transactionid=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(1, transactionid);
			ArtTransactionBean atb=new ArtTransactionBean();
			rs=stmt.executeQuery();
			l=new ArrayList<ArtTransactionBean>();
			while(rs.next()){
				atb.setTransactionId(rs.getInt("TRANSACTIONID"));
				atb.setArtId(rs.getInt("ARTID"));
				atb.setCustomerId(rs.getInt("CUSTID"));
				atb.setPrice(rs.getDouble("PRICE"));
				l.add(atb);
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
				if(rs!=null){
					rs.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		return l;
	}
	
	public List<ArtTransactionBean> getBillDetails(int custid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String query="select artid,price from T_XBBNHHA_TRANSACTION where custid=?";
		List<ArtTransactionBean> l=null;
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(1,custid);
			rs=stmt.executeQuery();
			l=new ArrayList<ArtTransactionBean>();
			while(rs.next()){
				ArtTransactionBean a=new ArtTransactionBean();
				a.setArtId(rs.getInt("ARTID"));
				a.setPrice(rs.getDouble("PRICE"));
				l.add(a);
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
				if(rs!=null){
					rs.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		return l;
	}
	public double billtotal(int custid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		double sum=0.0;
		double price=0.0;
		String query="select price from T_XBBNHHA_TRANSACTION where custid=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(1,custid);
			rs=stmt.executeQuery();
			while(rs.next()){
				price=rs.getDouble("PRICE");
				sum+=price;
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
				if(rs!=null){
					rs.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		return sum;
	}
	
	public String getArtDetail(int artid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String arttype="";
		String query="select arttype from T_XBBNHHA_ARTWORK where artid=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(1,artid);
			rs=stmt.executeQuery();
			while(rs.next()){
				arttype=rs.getString("ARTTYPE");
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
				if(rs!=null){
					rs.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		return arttype;
	}
	
	public String returnName(int custid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String query="select custname from T_XBBNHHA_CUSTOMER where custid=?";
		String custname="";
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(1,custid);
			rs=stmt.executeQuery();
			while(rs.next()){
				custname=rs.getString("CUSTNAME");
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
				if(rs!=null){
					rs.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		return custname;
	}
	public String getArtType(int artid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String arttype=null;
		String query="select arttype from T_XBBNHHA_ARTWORK where artid=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(1,artid);
			rs=stmt.executeQuery();
			while(rs.next()){
				arttype=rs.getString("ARTTYPE");
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		return arttype;
	}
}