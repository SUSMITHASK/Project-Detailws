package com.inautix.ArtGallery;

public class ArtCustomerBean{
	private int custid;
	private String custname;
	private String custaddr;
	private String custphoneno;
    private String passwd;
   
	
	public void setCustId(int custid){
		this.custid=custid;
	}
	
	public int getCustId(){
		return custid;
	}
	
	public void setCustAddr(String custaddr){
		this.custaddr=custaddr;
	}
	
	public String getCustAddr(){
		return custaddr;
	}
	
	public void setCustName(String custname){
		this.custname=custname;
	}
	
	public String getCustName(){
		return custname;
	}
	
	public void setCustPhoneNo(String custphoneno){
		this.custphoneno=custphoneno;
	}
	
	public String getCustPhoneNo(){
		return custphoneno;
	}
	public void setPasswd(String passwd){
		this.passwd=passwd;
	}
	
	public String getPasswd(){
		return passwd;
	}
}