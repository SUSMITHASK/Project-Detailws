package com.inautix.ArtGallery;

import java.util.*;



public class ArtArtistApp{
	

	
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the choice");
		System.out.println("1.insert 2.update 3.delete 4.select");
		int choice=sc.nextInt();
		int artistid;
		ArtArtistDao aad=new ArtArtistDao();
		switch(choice){
		case 1:
			System.out.println("Enter the artist name");
			String artistname=sc.next();
			System.out.println("Enter the artist address");
			sc.nextLine();
			String artistaddr=sc.nextLine();
			System.out.println("Enter the artist phone no");
			String contactinfo=sc.nextLine();
			System.out.println("Enter the password");
			String apasswd=sc.next();
			aad.insert(artistname,artistaddr,contactinfo,apasswd);
			break;
			
		case 2:
			System.out.println("Enter the artist id");
			artistid=sc.nextInt();
			System.out.println("Enter the choice");
			System.out.println("1.Artist name 2.Artist Address 3.Artist Contact no");
			int ch=sc.nextInt();
			switch(ch){
			case 1:
				aad.updateName(artistid);
				break;
			case 2:
				aad.updateAddr(artistid);
				break;
			case 3:
				aad.updateContact(artistid);
				break;
			default:
				System.out.println("Enter choice between 1 and 3");	
			}
			break;
			
		case 3:
			System.out.println("Enter the artist id");
			artistid=sc.nextInt();
			aad.delete(artistid);
			break;
			
		case 4:
			System.out.println("Enter the artistid");
			artistid=sc.nextInt();
			List<ArtArtistBean> aab=aad.select(artistid);
			Iterator<ArtArtistBean> it=aab.iterator();
			while(it.hasNext()){
				ArtArtistBean aabo=it.next();
				System.out.println(aabo.getArtistId()+"/"+aabo.getArtistName()+"/"+aabo.getArtistAddr()+"/"+aabo.getArtistContact());
			}
			break;
			
		default:
			System.out.println("Enter the choice between 1 and 4");
		}
		sc.close();
	}
}