package com.inautix.ArtGallery;

import java.sql.*;
import java.util.*;



public class ArtCustomerDao{
	
	
	
	public void insertDetails(String custname,String custaddr,String custphoneno,String passwd){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		String query="insert into T_XBBNHHA_CUSTOMER(custname,custaddr,custphoneno) values(?,?,?)";
		String query1="insert into T_XBBNHHA_CUST_LOGIN values(?,?)";
		try{
			stmt=con.prepareStatement(query);
			//stmt.setInt(1,custid);
			stmt.setString(1,custname);
			stmt.setString(2,custaddr);
			stmt.setString(3,custphoneno);
			stmt.executeUpdate();
			
			stmt.close();
			stmt=con.prepareStatement(query1);
			stmt.setString(1,custname);
			stmt.setString(2,passwd);
			stmt.executeUpdate();
			System.out.println("Inserted details successfully");
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
	}
	
	public List<ArtCustomerBean> display(int custid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		List<ArtCustomerBean> details=null;
		String query="Select * from T_XBBNHHA_CUSTOMER where custid=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(1,custid);
			rs=stmt.executeQuery();
			details=new ArrayList<ArtCustomerBean>();
			while(rs.next()){
				ArtCustomerBean acb=new ArtCustomerBean();
				acb.setCustId(rs.getInt("CUSTID"));
				acb.setCustName(rs.getString("CUSTNAME"));
				acb.setCustAddr(rs.getString("CUSTADDR"));
				acb.setCustPhoneNo(rs.getString("CUSTPHONENO"));
				details.add(acb);
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		return details;
	}
	
	public void updateName(int custid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter new customer name:");
		String custname=sc.next();
		String query="update T_XBBNHHA_CUSTOMER set custname=? where custid=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(2,custid);
			stmt.setString(1,custname);
			stmt.executeUpdate();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		System.out.println("Updated customer name successfully!");
		sc.close();
	}
	
	public void updateAddress(int custid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the customer address");
		String custaddr=sc.next();
		String query="update T_XBBNHHA_CUSTOMER set custaddr=? where custid=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(2,custid);
			stmt.setString(1,custaddr);
			stmt.executeUpdate();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		System.out.println("Updated customer address successfully!");
		sc.close();
	}
	
	public void updatePhoneNo(int custid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the customer phone no");
		String custphoneno=sc.next();
		String query="update T_XBBNHHA_CUSTOMER set custphoneno=? where custid=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(2,custid);
			stmt.setString(1,custphoneno);
			stmt.executeUpdate();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		System.out.println("Updated customer contact no successfully!");
		sc.close();
	}
	
	public void delete(int custid){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		String query="Delete from T_XBBNHHA_CUSTOMER where custid=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setInt(1,custid);
			stmt.executeUpdate();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		System.out.println("Deleted the row successfully!");
	}
	public int checkLogin(String uname,String pwd){
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		int r=0;
		String query="select * from T_XBBNHHA_CUST_LOGIN where uname=? and passwd=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setString(1,uname);
			stmt.setString(2,pwd);
			rs=stmt.executeQuery();
			while(rs.next()){
				r=1;
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
				if(rs!=null){
					rs.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		return r;
	}

	public int getCustId(String custname) {
		// TODO Auto-generated method stub
		Connection con=ConnectionCreation.getConn();
		PreparedStatement stmt=null;
		ResultSet rs=null;
		int custid=0;
		String query="select custid from T_XBBNHHA_CUSTOMER where custname=?";
		try{
			stmt=con.prepareStatement(query);
			stmt.setString(1,custname);
			rs=stmt.executeQuery();
			while(rs.next()){
				custid=rs.getInt("CUSTID");
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				if(stmt!=null){
					stmt.close();
				}
				if(con!=null){
					con.close();
				}
				if(rs!=null){
					rs.close();
				}
			}
			catch(SQLException e){
				e.printStackTrace();
			}
		}
		return custid;
	}
}